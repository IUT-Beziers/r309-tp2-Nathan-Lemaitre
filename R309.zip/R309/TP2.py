import tkinter as tk
from tkinter import simpledialog
from PIL import Image, ImageTk
from tkinter import Tk, simpledialog, Label, Entry, Button

class ApplicationDessinReseau:
    def __init__(self, racine):
        self.racine = racine
        self.racine.title("Cisco Packet Tracer de wish")

        self.canvas = tk.Canvas(racine, bg="white", width=800, height=600)
        self.canvas.pack(expand=tk.YES, fill=tk.BOTH)

        self.elements_reseau = []
        self.cables = []
        self.element_courant = None
        self.suppression_active = False
        self.creer_cable_active = False
        self.point_depart_cable = None

        self.images = {} 
        self.fenetres_contextuelles = {}
        
        self.deplacer_element = False
        self.element_en_deplacement = None
        self.offset_x = 0
        self.offset_y = 0

        self.initialiser_menu()
        self.initialiser_evenements()   
        self.fenetre_contextuelle = None 

    def initialiser_menu(self):
        self.barre_menu = tk.Menu(self.racine)
        self.racine.config(menu=self.barre_menu)

        menu_fichier = tk.Menu(self.barre_menu, tearoff=0)
        self.barre_menu.add_cascade(label="Fichier", menu=menu_fichier)
        menu_fichier.add_command(label="Quitter", command=self.racine.destroy)

        menu_element = tk.Menu(self.barre_menu, tearoff=0)
        self.barre_menu.add_cascade(label="Éléments", menu=menu_element)
        menu_element.add_command(label="Nouveau Client", command=lambda: self.creer_element_image("pc.png"))
        menu_element.add_command(label="Nouveau Switch", command=lambda: self.creer_element_image("switch.png"))
        menu_element.add_command(label="Nouveau Routeur", command=lambda: self.creer_element_image("routeur.png"))
        menu_element.add_command(label="Nouveau Câble", command=self.preparer_creation_cable)

        menu_action = tk.Menu(self.barre_menu, tearoff=0)
        self.barre_menu.add_cascade(label="Action", menu=menu_action)
        menu_action.add_command(label="Supprimer", command=self.preparer_suppression)

    def afficher_nb_ports_survol_element(self, event):
        if self.fenetre_contextuelle:  # S'il y a déjà une fenêtre ouverte, ne rien faire
            return
        
        x, y = event.x, event.y
        element = self.canvas.find_closest(x, y)
        
        if element:
            id_element = element[0]
            proprietes_element = self.obtenir_element_par_id(id_element)
            
            if proprietes_element and "nb_ports" in proprietes_element:
                nb_ports = proprietes_element["nb_ports"]
                ports_info = "\n".join([f"Port {i}" for i in range(1, nb_ports + 1)])

                self.fenetre_contextuelle = tk.Toplevel(self.racine)
                self.fenetre_contextuelle.wm_overrideredirect(1)  # Pour supprimer les bordures de la fenêtre

                self.fenetre_contextuelle.wm_geometry(f"+{event.x_root + 10}+{event.y_root + 10}")  # Positionnement de la fenêtre

                etiquette = tk.Label(self.fenetre_contextuelle, text=ports_info, padx=5, pady=3, bg="lightyellow", relief=tk.RIDGE)
                etiquette.pack()

    def cacher_fenetre_contextuelle(self, event):
        if self.fenetre_contextuelle:
            self.fenetre_contextuelle.destroy()
            self.fenetre_contextuelle = None

    def initialiser_evenements(self):
        self.canvas.bind("<Button-1>", self.sur_clic_canvas)
        self.canvas.bind("<B1-Motion>", self.sur_deplacement_canvas)
        self.canvas.bind("<ButtonRelease-1>", self.sur_relachement_canvas)
        self.canvas.bind("<Button-3>", self.afficher_proprietes_element)

        self.racine.state_ctrl = False
        self.racine.bind("<Control-Key>", self.activer_ctrl)
        self.racine.bind("<Control-KeyRelease>", self.desactiver_ctrl)
        self.canvas.tag_bind("element", "<Motion>", self.afficher_nb_ports_survol_element)
        self.canvas.tag_bind("element", "<Leave>", self.cacher_fenetre_contextuelle)

    def activer_ctrl(self, event):
        self.racine.state_ctrl = True

    def desactiver_ctrl(self, event):
        self.racine.state_ctrl = False

    def creer_element_image(self, image_filename):
        x, y = self.obtenir_position_aleatoire()
        element = {
            "id": len(self.elements_reseau) + 1,
            "nom": f"{image_filename.split('.')[0].capitalize()} {len([elem for elem in self.elements_reseau if elem['image'] == image_filename]) + 1}",
            "icone": None,
            "texte": None,
            "image": image_filename
        }

        if image_filename not in self.images:
            image = Image.open(image_filename)
            image.thumbnail((40, 40))
            self.images[image_filename] = ImageTk.PhotoImage(image)

        element["icone"], element["texte"] = self.dessiner_element_image(x, y, self.images[image_filename], element["nom"])
        self.elements_reseau.append(element)

    def dessiner_element_image(self, x, y, image, nom):
        icone = self.canvas.create_image(x, y, image=image, anchor=tk.CENTER, tags="element")
        texte = self.canvas.create_text(x, y + 50, text=nom, tags="element")
        return icone, texte
    
    def sur_clic_canvas(self, event):
        x, y = event.x, event.y
        elements = self.canvas.find_withtag("element")
        element_clique = None
        
        for element in elements:
            bbox = self.canvas.bbox(element)
            if bbox[0] <= x <= bbox[2] and bbox[1] <= y <= bbox[3]:
                element_clique = element
                break
        
        if element_clique and self.creer_cable_active:
            if self.point_depart_cable is None:
                self.point_depart_cable = element_clique
            else:
                point_arrivee = element_clique
                self.creer_cable_entre_elements(self.point_depart_cable, point_arrivee)
        else:
            x, y = event.x, event.y
            elements = self.canvas.find_withtag("element")
            for element in elements:
                bbox = self.canvas.bbox(element)
                if bbox[0] <= x <= bbox[2] and bbox[1] <= y <= bbox[3]:
                    self.deplacer_element = True
                    self.element_en_deplacement = element
                    self.offset_x = x - bbox[0]
                    self.offset_y = y - bbox[1]
                    break

    def creer_cable_entre_elements(self, point_depart, point_arrivee):
        if point_depart and point_arrivee:
            x1, y1 = self.canvas.coords(point_depart)[0], self.canvas.coords(point_depart)[1]
            x2, y2 = self.canvas.coords(point_arrivee)[0], self.canvas.coords(point_arrivee)[1]

            if self.racine.state_ctrl:
                if abs(x1 - x2) > abs(y1 - y2):
                    y2 = y1
                else:
                    x2 = x1

            cable = self.canvas.create_line(x1, y1, x2, y2, fill="black", width=2, tags="cable")
            self.cables.append({"id": cable, "points": [(point_depart, x1, y1), (point_arrivee, x2, y2)]})
            self.point_depart_cable = None
            self.creer_cable_active = False

    def sur_deplacement_canvas(self, event):
        if self.deplacer_element and self.element_en_deplacement:
            x, y = event.x, event.y
            bbox = self.canvas.bbox(self.element_en_deplacement)
            dx, dy = x - bbox[0] - self.offset_x, y - bbox[1] - self.offset_y
            self.canvas.move(self.element_en_deplacement, dx, dy)
            texte_id = self.obtenir_texte_par_id(self.element_en_deplacement)
            if texte_id:
                self.canvas.move(texte_id, dx, dy)
            self.mettre_a_jour_cables(self.element_en_deplacement, (dx, dy))

    def sur_relachement_canvas(self, event):
        self.deplacer_element = False
        self.element_en_deplacement = None
                
    def afficher_proprietes_element(self, event):
        x, y = event.x, event.y
        element = self.canvas.find_closest(x, y)
        if element:
            id_element = element[0]
            proprietes_element = self.obtenir_element_par_id(id_element)
            if proprietes_element:
                root = Tk()
                root.title("Propriétés de l'élément")

                Label(root, text="Nouveau nom :").pack()
                nouveau_nom_entry = Entry(root, width=30)
                nouveau_nom_entry.insert(0, proprietes_element["nom"])
                nouveau_nom_entry.pack()

                Label(root, text="Nombre de ports :").pack()
                nb_ports_entry = Entry(root, width=10)
                nb_ports_entry.insert(0, str(proprietes_element.get("nb_ports", 0)))
                nb_ports_entry.pack()

        def mettre_a_jour_proprietes():
            nouveau_nom = nouveau_nom_entry.get()
            proprietes_element["nom"] = nouveau_nom

            nb_ports = int(nb_ports_entry.get())
            proprietes_element["nb_ports"] = nb_ports

 
            texte_id = self.obtenir_texte_par_id(id_element)
            if texte_id:
                self.canvas.itemconfig(texte_id, text=nouveau_nom)  
            root.destroy()

        def valider_evenement(event):
            mettre_a_jour_proprietes()
        nouveau_nom_entry.bind("<Return>", valider_evenement) 
        nb_ports_entry.bind("<Return>", valider_evenement) 
        bouton_valider = Button(root, text="Valider")

    def preparer_suppression(self):
        self.suppression_active = True
        for element in self.elements_reseau:
            self.canvas.tag_unbind(element["icone"], "<Button-1>")
            self.canvas.tag_bind(element["icone"], "<Button-1>", lambda event, id_element=element["icone"]: self.supprimer_element_clic(event, id_element))

    def preparer_creation_cable(self):
        self.creer_cable_active = True
        self.point_depart_cable = None

    def dessiner_cable(self, point_depart, point_arrivee):
        x1, y1 = self.canvas.coords(point_depart["id"])[0], self.canvas.coords(point_depart["id"])[1]
        x2, y2 = self.canvas.coords(point_arrivee["id"])[0], self.canvas.coords(point_arrivee["id"])[1]
        cable = self.canvas.create_line(x1, y1, x2, y2, fill="black", width=2, tags="cable")
        self.cables.append({"id": cable, "points": [point_depart, point_arrivee]})

    def supprimer_element_clic(self, event, id_element=None):
        if id_element is None:
            x, y = event.x, event.y
            element = self.canvas.find_closest(x, y)
            if element:
                id_element = element[0]

        if self.suppression_active:
            self.supprimer_cable_par_element(id_element)  

            texte_id = self.obtenir_texte_par_id(id_element)
            self.canvas.delete(id_element)
            if texte_id:
                self.canvas.delete(texte_id)
            self.elements_reseau = [elem for elem in self.elements_reseau if elem["icone"] != id_element]
            self.deselectionner_element()
            self.suppression_active = False

            for element in self.elements_reseau:
                self.canvas.tag_unbind(element["icone"], "<Button-1>")
                self.canvas.tag_bind(element["icone"], "<Button-1>", lambda ev, id_elem=element["icone"]: self.supprimer_element_clic(ev, id_elem))

    def deselectionner_element(self):
        for element in self.elements_reseau:
            self.canvas.itemconfig(element["icone"], outline="black", width=1)

    def obtenir_position_aleatoire(self):
        return 100, 100

    def obtenir_element_par_id(self, id_element):
        for element in self.elements_reseau:
            if element["icone"] == id_element:
                return element  
        return None

    def obtenir_texte_par_id(self, id_element):
        for element in self.elements_reseau:
            if element["icone"] == id_element:
                return element["texte"]
        return None

    def supprimer_cable_par_element(self, id_element):
        cables_a_supprimer = [cable for cable in self.cables if any(point[0] == id_element for point in cable["points"])]
        for cable in cables_a_supprimer:
            self.canvas.delete(cable["id"])
            self.cables.remove(cable)

    def mettre_a_jour_cables(self, id_element, delta):
        for cable in self.cables:
            for index, point in enumerate(cable["points"]):
                if point[0] == id_element:
                    element, x, y = point
                    new_point = (element, x + delta[0], y + delta[1])
                    cable["points"][index] = new_point
                    x1, y1 = cable["points"][0][1], cable["points"][0][2]
                    x2, y2 = cable["points"][1][1], cable["points"][1][2]
                    self.canvas.coords(cable["id"], x1, y1, x2, y2)

if __name__ == "__main__":
    racine = tk.Tk()
    app = ApplicationDessinReseau(racine)
    racine.mainloop()
